require("dotenv").config();

module.exports = {
  APP_NAME: process.env.APP_NAME || "نظام راكان الاحترافي",
  DEFAULT_CITY: process.env.DEFAULT_CITY || "جدة",
  PORT: parseInt(process.env.PORT || "3000", 10),
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || "7d"
};
