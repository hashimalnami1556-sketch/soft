const cron = require("node-cron");
const { createBackup } = require("./backup");
const { readDB, writeDB } = require("../db");

function checkDelayedClients() {
  const db = readDB();
  const delayed = db.clients.filter((c) => Number(c.balance || 0) < 0);
  if (delayed.length > 0) {
    db.logs.push({
      timestamp: new Date().toISOString(),
      action: `فحص تلقائي: ${delayed.length} عميل متعثر`,
      user: "system"
    });
    writeDB(db);
  }
  return delayed.length;
}

function startScheduler() {
  cron.schedule("0 3 * * *", () => {
    createBackup();
  });

  cron.schedule("0 0 * * *", () => {
    checkDelayedClients();
  });

  setTimeout(() => {
    try { createBackup(); } catch (_) {}
  }, 3000);
}

module.exports = { startScheduler, checkDelayedClients };
