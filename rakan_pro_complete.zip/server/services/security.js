const attempts = new Map();

const MAX_ATTEMPTS = 5;
const BLOCK_DURATION = 15 * 60 * 1000;

function recordFailedAttempt(username) {
  const now = Date.now();
  const record = attempts.get(username) || { count: 0, firstAttempt: now };
  if (now - record.firstAttempt > BLOCK_DURATION) {
    attempts.set(username, { count: 1, firstAttempt: now });
    return;
  }
  record.count += 1;
  attempts.set(username, record);
}

function isBlocked(username) {
  const record = attempts.get(username);
  if (!record) return false;
  if (Date.now() - record.firstAttempt > BLOCK_DURATION) {
    attempts.delete(username);
    return false;
  }
  return record.count >= MAX_ATTEMPTS;
}

function resetAttempts(username) {
  attempts.delete(username);
}

module.exports = {
  recordFailedAttempt,
  isBlocked,
  resetAttempts,
  MAX_ATTEMPTS,
  BLOCK_DURATION
};
