const fs = require("fs");
const path = require("path");
const { DB_PATH } = require("../db");

const BACKUP_DIR = path.join(__dirname, "../../backups");

function ensureBackupDir() {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
}

function createBackup() {
  ensureBackupDir();
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const filename = `backup-${timestamp}.json`;
  const target = path.join(BACKUP_DIR, filename);
  fs.copyFileSync(DB_PATH, target);

  const files = fs.readdirSync(BACKUP_DIR)
    .filter((f) => f.startsWith("backup-") && f.endsWith(".json"))
    .sort()
    .reverse();

  for (const oldFile of files.slice(7)) {
    fs.unlinkSync(path.join(BACKUP_DIR, oldFile));
  }

  return { filename, path: target };
}

module.exports = { BACKUP_DIR, createBackup };
