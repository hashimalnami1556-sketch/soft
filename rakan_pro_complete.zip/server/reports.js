const ExcelJS = require("exceljs");
const { readDB } = require("./db");

function getFinancialReport(req, res) {
  const db = readDB();
  const clients = db.clients || [];

  const totalBalance = clients.reduce((sum, c) => sum + Number(c.balance || 0), 0);
  const activeCount = clients.filter((c) => c.status === "نشط").length;
  const vipCount = clients.filter((c) => c.category === "VIP").length;
  const totalClients = clients.length;

  const byCity = clients.reduce((acc, c) => {
    const key = c.city || "غير محدد";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  const byCategory = {
    VIP: clients.filter((c) => c.category === "VIP").length,
    "عادي": clients.filter((c) => c.category === "عادي").length,
    "متعثر": clients.filter((c) => c.category === "متعثر").length
  };

  res.json({
    success: true,
    data: {
      summary: { totalClients, activeCount, vipCount, totalBalance },
      byCity,
      byCategory
    }
  });
}

async function exportToExcel(req, res) {
  const db = readDB();
  const clients = db.clients || [];

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("العملاء");

  worksheet.columns = [
    { header: "المعرف", key: "id", width: 10 },
    { header: "الاسم", key: "name", width: 30 },
    { header: "رقم الجوال", key: "phone", width: 18 },
    { header: "المدينة", key: "city", width: 15 },
    { header: "الحالة", key: "status", width: 12 },
    { header: "الفئة", key: "category", width: 12 },
    { header: "الرصيد", key: "balance", width: 14 },
    { header: "تاريخ التسجيل", key: "createdAt", width: 24 },
    { header: "ملاحظات", key: "notes", width: 40 }
  ];

  clients.forEach((client) => worksheet.addRow(client));
  worksheet.getRow(1).font = { bold: true };
  worksheet.views = [{ rightToLeft: true }];

  res.setHeader(
    "Content-Type",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  );
  res.setHeader(
    "Content-Disposition",
    `attachment; filename*=UTF-8''${encodeURIComponent("تقرير_العملاء.xlsx")}`
  );

  await workbook.xlsx.write(res);
  res.end();
}

module.exports = { getFinancialReport, exportToExcel };
