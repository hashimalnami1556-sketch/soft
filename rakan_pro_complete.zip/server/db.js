const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "database.json");

function ensureDB() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify({
      clients: [],
      users: [],
      logs: [],
      settings: {
        companyName: "مؤسسة النعمي",
        companyPhone: "",
        companyEmail: "",
        defaultCity: "جدة"
      }
    }, null, 2), "utf8");
  }
}

function readDB() {
  ensureDB();
  return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf8");
}

function addLog(action, user = "system") {
  const db = readDB();
  db.logs.push({
    timestamp: new Date().toISOString(),
    action,
    user
  });
  writeDB(db);
}

module.exports = { DB_PATH, ensureDB, readDB, writeDB, addLog };
