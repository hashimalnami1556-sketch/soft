require("dotenv").config();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");

const { authenticateToken, authorizeAdmin, loginHandler, registerHandler } = require("./auth");
const { getFinancialReport, exportToExcel } = require("./reports");
const { ensureDB, readDB, writeDB, addLog } = require("./db");
const { createBackup } = require("./services/backup");
const { startScheduler } = require("./services/scheduler");
const config = require("../config/settings");

ensureDB();

const app = express();
const PORT = config.PORT;
const uploadsDir = path.join(__dirname, "uploads");

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: "تم تجاوز عدد الطلبات المسموح به مؤقتًا" }
});

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, "_")}`)
});

const upload = multer({
  storage,
  fileFilter: (_req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) {
      return cb(new Error("يسمح فقط برفع الصور"));
    }
    cb(null, true);
  },
  limits: { fileSize: 2 * 1024 * 1024 }
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));
app.use("/api", limiter);
app.use(express.static(path.join(__dirname, "../client")));
app.use("/uploads", express.static(uploadsDir));

startScheduler();

function sanitizeClientPayload(payload) {
  const balanceNum = Number(payload.balance || 0);
  const category = ["VIP", "عادي", "متعثر"].includes(payload.category) ? payload.category : "عادي";
  return {
    name: String(payload.name || "").trim() || "غير محدد",
    phone: String(payload.phone || "").trim() || "غير محدد",
    city: String(payload.city || config.DEFAULT_CITY).trim() || config.DEFAULT_CITY,
    status: String(payload.status || "نشط").trim() || "نشط",
    balance: Number.isFinite(balanceNum) ? balanceNum : 0,
    category,
    notes: String(payload.notes || "").trim()
  };
}

app.get("/api/health", (_req, res) => {
  res.json({ success: true, app: config.APP_NAME, port: PORT });
});

app.post("/api/auth/login", loginHandler);
app.post("/api/auth/register", authenticateToken, authorizeAdmin, registerHandler);

app.get("/api/clients", authenticateToken, (req, res) => {
  const db = readDB();
  let data = db.clients;
  const limit = Number(req.query.limit || 0);
  if (limit > 0) data = data.slice(0, limit);
  res.json({ success: true, data });
});

app.get("/api/clients/search", authenticateToken, (req, res) => {
  const db = readDB();
  const q = String(req.query.q || "").trim().toLowerCase();
  const city = String(req.query.city || "").trim();
  const category = String(req.query.category || "").trim();
  const status = String(req.query.status || "").trim();

  let results = db.clients;

  if (q) {
    results = results.filter((c) =>
      String(c.name || "").toLowerCase().includes(q) ||
      String(c.phone || "").includes(q) ||
      String(c.notes || "").toLowerCase().includes(q)
    );
  }
  if (city) results = results.filter((c) => c.city === city);
  if (category) results = results.filter((c) => c.category === category);
  if (status) results = results.filter((c) => c.status === status);

  res.json({ success: true, data: results });
});

app.post("/api/clients", authenticateToken, upload.single("avatar"), (req, res) => {
  const db = readDB();
  const payload = sanitizeClientPayload(req.body);
  const newId = db.clients.length ? Math.max(...db.clients.map((c) => c.id)) + 1 : 1;

  const client = {
    id: newId,
    ...payload,
    createdAt: new Date().toISOString(),
    avatar: req.file ? `/uploads/${req.file.filename}` : null
  };

  db.clients.push(client);
  db.logs.push({
    timestamp: new Date().toISOString(),
    action: `إضافة عميل ${client.name}`,
    user: req.user.username
  });
  writeDB(db);

  res.status(201).json({ success: true, data: client });
});

app.put("/api/clients/:id", authenticateToken, (req, res) => {
  const db = readDB();
  const id = Number(req.params.id);
  const idx = db.clients.findIndex((c) => c.id === id);
  if (idx === -1) {
    return res.status(404).json({ success: false, message: "العميل غير موجود" });
  }

  const payload = sanitizeClientPayload(req.body);
  db.clients[idx] = { ...db.clients[idx], ...payload, id };
  db.logs.push({
    timestamp: new Date().toISOString(),
    action: `تعديل عميل رقم ${id}`,
    user: req.user.username
  });
  writeDB(db);

  res.json({ success: true, data: db.clients[idx] });
});

app.delete("/api/clients/:id", authenticateToken, (req, res) => {
  const db = readDB();
  const id = Number(req.params.id);
  const before = db.clients.length;
  db.clients = db.clients.filter((c) => c.id !== id);
  if (db.clients.length === before) {
    return res.status(404).json({ success: false, message: "العميل غير موجود" });
  }
  db.logs.push({
    timestamp: new Date().toISOString(),
    action: `حذف عميل رقم ${id}`,
    user: req.user.username
  });
  writeDB(db);
  res.json({ success: true, message: "تم الحذف" });
});

app.get("/api/stats", authenticateToken, (_req, res) => {
  const db = readDB();
  const total = db.clients.length;
  const active = db.clients.filter((c) => c.status === "نشط").length;
  const totalBalance = db.clients.reduce((sum, c) => sum + Number(c.balance || 0), 0);
  const vip = db.clients.filter((c) => c.category === "VIP").length;
  const delayed = db.clients.filter((c) => Number(c.balance || 0) < 0).length;
  res.json({ success: true, data: { total, active, totalBalance, vip, delayed } });
});

app.get("/api/reports/financial", authenticateToken, getFinancialReport);
app.get("/api/reports/export/excel", authenticateToken, exportToExcel);

app.get("/api/logs", authenticateToken, authorizeAdmin, (_req, res) => {
  const db = readDB();
  res.json({ success: true, data: db.logs.slice().reverse().slice(0, 50) });
});

app.get("/api/users", authenticateToken, authorizeAdmin, (_req, res) => {
  const db = readDB();
  const users = db.users.map(({ password, ...rest }) => rest);
  res.json({ success: true, data: users });
});

app.delete("/api/users/:id", authenticateToken, authorizeAdmin, (req, res) => {
  const db = readDB();
  const id = Number(req.params.id);
  if (id === 1) {
    return res.status(400).json({ success: false, message: "لا يمكن حذف المدير الرئيسي" });
  }
  const before = db.users.length;
  db.users = db.users.filter((u) => u.id !== id);
  if (before === db.users.length) {
    return res.status(404).json({ success: false, message: "المستخدم غير موجود" });
  }
  writeDB(db);
  addLog(`حذف مستخدم رقم ${id}`, req.user.username);
  res.json({ success: true, message: "تم حذف المستخدم" });
});

app.put("/api/users/change-password", authenticateToken, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ success: false, message: "البيانات غير مكتملة" });
  }

  const db = readDB();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) {
    return res.status(404).json({ success: false, message: "المستخدم غير موجود" });
  }

  if (!bcrypt.compareSync(currentPassword, user.password)) {
    return res.status(400).json({ success: false, message: "كلمة المرور الحالية غير صحيحة" });
  }

  user.password = bcrypt.hashSync(newPassword, 10);
  writeDB(db);
  addLog("تغيير كلمة المرور", req.user.username);
  res.json({ success: true, message: "تم تغيير كلمة المرور بنجاح" });
});

app.get("/api/settings", authenticateToken, (_req, res) => {
  const db = readDB();
  res.json({ success: true, data: db.settings || {} });
});

app.put("/api/settings", authenticateToken, authorizeAdmin, (req, res) => {
  const db = readDB();
  db.settings = {
    ...db.settings,
    companyName: String(req.body.companyName || db.settings.companyName || "").trim(),
    companyPhone: String(req.body.companyPhone || db.settings.companyPhone || "").trim(),
    companyEmail: String(req.body.companyEmail || db.settings.companyEmail || "").trim(),
    defaultCity: String(req.body.defaultCity || db.settings.defaultCity || config.DEFAULT_CITY).trim()
  };
  writeDB(db);
  addLog("تحديث إعدادات النظام", req.user.username);
  res.json({ success: true, data: db.settings, message: "تم حفظ الإعدادات" });
});

app.post("/api/backups/manual", authenticateToken, authorizeAdmin, (_req, res) => {
  const result = createBackup();
  addLog(`إنشاء نسخة احتياطية ${result.filename}`, req.user.username);
  res.json({ success: true, data: result, message: "تم إنشاء النسخة الاحتياطية" });
});

app.use((err, _req, res, _next) => {
  return res.status(400).json({ success: false, message: err.message || "حدث خطأ" });
});

app.listen(PORT, () => {
  console.log(`✅ ${config.APP_NAME} يعمل على http://localhost:${PORT}`);
});
