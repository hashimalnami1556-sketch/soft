const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { readDB, writeDB, addLog } = require("./db");
const security = require("./services/security");

const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME";

function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ success: false, message: "لم يتم توفير رمز الدخول" });
  }

  try {
    const user = jwt.verify(token, JWT_SECRET);
    req.user = user;
    next();
  } catch (error) {
    return res.status(403).json({ success: false, message: "الرمز غير صالح أو انتهت الجلسة" });
  }
}

function authorizeAdmin(req, res, next) {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({ success: false, message: "ليس لديك صلاحية" });
  }
  next();
}

function loginHandler(req, res) {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ success: false, message: "اسم المستخدم وكلمة المرور مطلوبان" });
  }

  if (security.isBlocked(username)) {
    return res.status(429).json({
      success: false,
      message: "تم تجاوز عدد المحاولات المسموحة. حاول لاحقًا."
    });
  }

  const db = readDB();
  const user = db.users.find((u) => u.username === username);

  if (!user) {
    security.recordFailedAttempt(username);
    return res.status(401).json({ success: false, message: "بيانات الدخول غير صحيحة" });
  }

  const validPassword = bcrypt.compareSync(password, user.password);
  if (!validPassword) {
    security.recordFailedAttempt(username);
    return res.status(401).json({ success: false, message: "بيانات الدخول غير صحيحة" });
  }

  security.resetAttempts(username);

  const token = jwt.sign(
    { id: user.id, username: user.username, role: user.role, fullName: user.fullName },
    JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );

  const { password: _hidden, ...userWithoutPassword } = user;
  addLog(`تسجيل دخول المستخدم ${user.username}`, user.username);

  return res.json({
    success: true,
    token,
    user: userWithoutPassword
  });
}

function registerHandler(req, res) {
  const { username, password, fullName, role } = req.body || {};
  if (!username || !password || !fullName) {
    return res.status(400).json({ success: false, message: "جميع الحقول مطلوبة" });
  }

  const db = readDB();
  if (db.users.find((u) => u.username === username)) {
    return res.status(400).json({ success: false, message: "اسم المستخدم موجود مسبقًا" });
  }

  const newId = db.users.length ? Math.max(...db.users.map((u) => u.id)) + 1 : 1;
  const newUser = {
    id: newId,
    username,
    password: bcrypt.hashSync(password, 10),
    role: role === "admin" ? "admin" : "user",
    fullName
  };

  db.users.push(newUser);
  writeDB(db);
  addLog(`إضافة مستخدم جديد ${username}`, req.user ? req.user.username : "system");

  const { password: _hidden, ...userWithoutPassword } = newUser;
  return res.status(201).json({ success: true, user: userWithoutPassword });
}

module.exports = {
  authenticateToken,
  authorizeAdmin,
  loginHandler,
  registerHandler
};
