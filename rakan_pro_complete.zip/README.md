# Rakan Pro Complete

نظام إدارة عملاء احترافي يتضمن:
- تسجيل دخول وصلاحيات JWT
- لوحة تحكم وإحصائيات ورسوم بيانية
- إدارة العملاء والمستخدمين
- تقارير مالية
- تصدير Excel
- نسخ احتياطي يومي ويدوي
- حماية من brute-force و rate limit

## التشغيل

1. انسخ ملف البيئة:
```bash
cp .env.example .env
```

2. ثبّت الاعتماديات:
```bash
npm install
```

3. شغّل النظام:
```bash
npm start
```

4. افتح:
```text
http://localhost:3000/login.html
```

## بيانات الدخول الافتراضية
- username: `admin`
- password: `password`

## ملاحظات
- يتم حفظ البيانات في `server/database.json`
- يتم حفظ النسخ الاحتياطية في `backups/`
- يتم حفظ الصور المرفوعة في `server/uploads/`
