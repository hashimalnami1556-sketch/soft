let cityChartRef = null;

async function initReportsPage() {
  const exportBtn = document.getElementById("exportFinancialExcel");
  if (exportBtn) {
    exportBtn.addEventListener("click", async () => {
      const res = await authFetch(`${API_BASE}/reports/export/excel`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `تقرير_العملاء_${new Date().toISOString().slice(0,10)}.xlsx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    });
  }

  const res = await authFetch(`${API_BASE}/reports/financial`);
  const data = await res.json();
  const summary = data.data.summary;
  const byCity = data.data.byCity;

  document.getElementById("reportSummary").innerHTML = `
    <div class="stat-card"><div class="stat-value">${summary.totalClients}</div><div class="stat-label">العملاء</div></div>
    <div class="stat-card"><div class="stat-value">${summary.activeCount}</div><div class="stat-label">نشطون</div></div>
    <div class="stat-card"><div class="stat-value">${summary.vipCount}</div><div class="stat-label">VIP</div></div>
    <div class="stat-card"><div class="stat-value">${Number(summary.totalBalance).toFixed(2)}</div><div class="stat-label">الرصيد الإجمالي</div></div>
  `;

  if (cityChartRef) cityChartRef.destroy();
  cityChartRef = new Chart(document.getElementById("cityChart"), {
    type: "bar",
    data: {
      labels: Object.keys(byCity),
      datasets: [{ label: "عدد العملاء", data: Object.values(byCity) }]
    }
  });
}
