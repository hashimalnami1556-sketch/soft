const API_BASE = `${window.location.origin}/api`;

if (localStorage.getItem("token") && location.pathname.endsWith("login.html")) {
  location.href = "index.html";
}

const form = document.getElementById("loginForm");
if (form) {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;
    const errorDiv = document.getElementById("loginError");
    errorDiv.textContent = "";

    try {
      const res = await fetch(`${API_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        errorDiv.textContent = data.message || "فشل تسجيل الدخول";
        return;
      }

      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      location.href = "index.html";
    } catch (error) {
      errorDiv.textContent = "تعذر الاتصال بالخادم";
    }
  });
}
