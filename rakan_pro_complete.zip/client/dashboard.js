let statusChartRef = null;
let categoryChartRef = null;

async function initDashboard() {
  await loadDashboardStats();
  await loadDashboardCharts();
  await loadRecentActivity();
}

async function loadDashboardStats() {
  const res = await authFetch(`${API_BASE}/reports/financial`);
  const data = await res.json();
  const s = data.data.summary;

  document.getElementById("statsGrid").innerHTML = `
    <div class="stat-card"><div class="stat-icon">👥</div><div class="stat-value">${s.totalClients}</div><div class="stat-label">إجمالي العملاء</div></div>
    <div class="stat-card"><div class="stat-icon">✅</div><div class="stat-value">${s.activeCount}</div><div class="stat-label">عملاء نشطون</div></div>
    <div class="stat-card"><div class="stat-icon">⭐</div><div class="stat-value">${s.vipCount}</div><div class="stat-label">VIP</div></div>
    <div class="stat-card"><div class="stat-icon">💰</div><div class="stat-value">${Number(s.totalBalance).toFixed(2)}</div><div class="stat-label">إجمالي الأرصدة</div></div>
  `;
}

async function loadDashboardCharts() {
  const reportRes = await authFetch(`${API_BASE}/reports/financial`);
  const report = await reportRes.json();
  const clientsRes = await authFetch(`${API_BASE}/clients`);
  const clientsData = await clientsRes.json();

  const statusCounts = clientsData.data.reduce((acc, c) => {
    acc[c.status] = (acc[c.status] || 0) + 1;
    return acc;
  }, {});

  if (statusChartRef) statusChartRef.destroy();
  if (categoryChartRef) categoryChartRef.destroy();

  statusChartRef = new Chart(document.getElementById("statusChart"), {
    type: "pie",
    data: {
      labels: Object.keys(statusCounts),
      datasets: [{ data: Object.values(statusCounts) }]
    }
  });

  categoryChartRef = new Chart(document.getElementById("categoryChart"), {
    type: "doughnut",
    data: {
      labels: Object.keys(report.data.byCategory),
      datasets: [{ data: Object.values(report.data.byCategory) }]
    }
  });
}

async function loadRecentActivity() {
  const res = await authFetch(`${API_BASE}/logs`);
  const data = await res.json();

  const html = data.data.slice(0, 8).map((item) => `
    <div class="activity-item">
      <span>${item.action}</span>
      <span class="activity-time">${new Date(item.timestamp).toLocaleString("ar-SA")}</span>
    </div>
  `).join("");

  document.getElementById("activityList").innerHTML = html || "<div>لا توجد عمليات حديثة</div>";
}
