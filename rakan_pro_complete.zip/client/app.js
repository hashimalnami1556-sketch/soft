const API_BASE = `${window.location.origin}/api`;
const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user") || "{}");

if (!token) {
  window.location.href = "login.html";
}

const userInfoEl = document.getElementById("userInfo");
if (userInfoEl) {
  userInfoEl.innerHTML = `
    <span>👤 ${user.fullName || user.username || ""}</span>
    <span class="badge-role ${user.role || "user"}">${user.role === "admin" ? "مدير" : "مستخدم"}</span>
  `;
}

document.querySelectorAll(".admin-only").forEach((el) => {
  if (user.role !== "admin") el.style.display = "none";
});

document.getElementById("logoutBtn").addEventListener("click", (e) => {
  e.preventDefault();
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "login.html";
});

const navLinks = document.querySelectorAll(".nav-link[data-page]");
const contentDiv = document.getElementById("pageContent");

async function authFetch(url, options = {}) {
  const isFormData = options.body instanceof FormData;
  const headers = {
    Authorization: `Bearer ${token}`,
    ...(isFormData ? {} : { "Content-Type": "application/json" }),
    ...(options.headers || {})
  };

  const response = await fetch(url, { ...options, headers });
  if (response.status === 401 || response.status === 403) {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "login.html";
    throw new Error("انتهت الجلسة");
  }
  return response;
}

async function fetchPageContent(page) {
  const res = await fetch(`pages/${page}.html`);
  return await res.text();
}

async function loadPage(page) {
  contentDiv.innerHTML = await fetchPageContent(page);

  switch (page) {
    case "dashboard":
      await initDashboard();
      break;
    case "clients":
      await initClientsPage();
      break;
    case "reports":
      await initReportsPage();
      break;
    case "users":
      await initUsersPage();
      break;
    case "settings":
      await initSettingsPage();
      break;
    default:
      contentDiv.innerHTML = "<h2>الصفحة غير موجودة</h2>";
  }

  navLinks.forEach((link) => link.classList.remove("active"));
  const active = document.querySelector(`[data-page="${page}"]`);
  if (active) active.classList.add("active");
}

navLinks.forEach((link) => {
  link.addEventListener("click", async (e) => {
    e.preventDefault();
    await loadPage(link.dataset.page);
  });
});

async function initClientsPage() {
  const modal = document.getElementById("clientFormContainer");
  const showBtn = document.getElementById("showAddFormBtn");
  const closeBtn = document.getElementById("closeClientForm");
  const form = document.getElementById("clientForm");
  const exportBtn = document.getElementById("exportExcelBtn");

  showBtn.addEventListener("click", () => openClientForm());
  closeBtn.addEventListener("click", () => closeClientForm());
  exportBtn.addEventListener("click", async () => {
    const res = await authFetch(`${API_BASE}/reports/export/excel`);
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "clients.xlsx";
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const id = document.getElementById("clientId").value;
    const payload = {
      name: document.getElementById("clientName").value,
      phone: document.getElementById("clientPhone").value,
      city: document.getElementById("clientCity").value,
      status: document.getElementById("clientStatus").value,
      category: document.getElementById("clientCategory").value,
      balance: document.getElementById("clientBalance").value,
      notes: document.getElementById("clientNotes").value
    };

    const url = id ? `${API_BASE}/clients/${id}` : `${API_BASE}/clients`;
    const method = id ? "PUT" : "POST";

    const res = await authFetch(url, { method, body: JSON.stringify(payload) });
    const data = await res.json();
    if (!res.ok || !data.success) {
      alert(data.message || "تعذر الحفظ");
      return;
    }

    closeClientForm();
    await loadClients();
  });

  document.getElementById("applyFilters").addEventListener("click", loadClients);
  document.getElementById("resetFilters").addEventListener("click", () => {
    document.getElementById("searchInput").value = "";
    document.getElementById("filterCity").value = "";
    document.getElementById("filterCategory").value = "";
    document.getElementById("filterStatus").value = "";
    loadClients();
  });

  await loadClients();

  function openClientForm(client = null) {
    modal.classList.remove("hidden");
    document.getElementById("formTitle").textContent = client ? "تعديل عميل" : "إضافة عميل";
    document.getElementById("clientId").value = client?.id || "";
    document.getElementById("clientName").value = client?.name || "";
    document.getElementById("clientPhone").value = client?.phone || "";
    document.getElementById("clientCity").value = client?.city || "";
    document.getElementById("clientStatus").value = client?.status || "نشط";
    document.getElementById("clientCategory").value = client?.category || "عادي";
    document.getElementById("clientBalance").value = client?.balance ?? 0;
    document.getElementById("clientNotes").value = client?.notes || "";
  }

  function closeClientForm() {
    modal.classList.add("hidden");
    form.reset();
    document.getElementById("clientId").value = "";
    document.getElementById("clientBalance").value = "0";
  }

  async function loadClients() {
    const q = document.getElementById("searchInput").value.trim();
    const city = document.getElementById("filterCity").value.trim();
    const category = document.getElementById("filterCategory").value;
    const status = document.getElementById("filterStatus").value;

    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (city) params.set("city", city);
    if (category) params.set("category", category);
    if (status) params.set("status", status);

    const url = params.toString() ? `${API_BASE}/clients/search?${params.toString()}` : `${API_BASE}/clients`;
    const res = await authFetch(url);
    const data = await res.json();

    renderClientsTable(data.data || []);
  }

  function renderClientsTable(clients) {
    const tbody = document.getElementById("tableBody");
    tbody.innerHTML = clients.map((c) => `
      <tr>
        <td>${c.id}</td>
        <td>${c.name}</td>
        <td>${c.phone}</td>
        <td>${c.city}</td>
        <td><span class="status-pill">${c.status}</span></td>
        <td><span class="badge-role ${c.category === "VIP" ? "admin" : ""}">${c.category}</span></td>
        <td>${Number(c.balance || 0).toFixed(2)}</td>
        <td class="actions-cell">
          <button class="btn-icon" data-edit="${c.id}">✏️</button>
          <button class="btn-icon danger" data-delete="${c.id}">🗑️</button>
        </td>
      </tr>
    `).join("");

    tbody.querySelectorAll("[data-edit]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = Number(btn.dataset.edit);
        const client = clients.find((c) => c.id === id);
        openClientForm(client);
      });
    });

    tbody.querySelectorAll("[data-delete]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = Number(btn.dataset.delete);
        if (!confirm("هل أنت متأكد من حذف العميل؟")) return;
        const res = await authFetch(`${API_BASE}/clients/${id}`, { method: "DELETE" });
        const data = await res.json();
        if (!res.ok || !data.success) {
          alert(data.message || "تعذر الحذف");
          return;
        }
        await loadClients();
      });
    });
  }
}

async function initUsersPage() {
  if (user.role !== "admin") {
    contentDiv.innerHTML = "<div class='settings-card'>ليس لديك صلاحية للوصول إلى هذه الصفحة.</div>";
    return;
  }

  const modal = document.getElementById("userFormContainer");
  document.getElementById("showAddUserFormBtn").addEventListener("click", () => modal.classList.remove("hidden"));
  document.getElementById("closeUserForm").addEventListener("click", () => modal.classList.add("hidden"));

  document.getElementById("userForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = {
      fullName: document.getElementById("userFullName").value,
      username: document.getElementById("userUsername").value,
      password: document.getElementById("userPassword").value,
      role: document.getElementById("userRole").value
    };

    const res = await authFetch(`${API_BASE}/auth/register`, {
      method: "POST",
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      alert(data.message || "تعذر إضافة المستخدم");
      return;
    }
    modal.classList.add("hidden");
    document.getElementById("userForm").reset();
    await loadUsers();
  });

  await loadUsers();

  async function loadUsers() {
    const res = await authFetch(`${API_BASE}/users`);
    const data = await res.json();
    const tbody = document.getElementById("usersTableBody");
    tbody.innerHTML = data.data.map((u) => `
      <tr>
        <td>${u.id}</td>
        <td>${u.fullName}</td>
        <td>${u.username}</td>
        <td><span class="badge-role ${u.role}">${u.role === "admin" ? "مدير" : "مستخدم"}</span></td>
        <td>${u.id !== 1 ? `<button class="btn-icon danger" data-delete-user="${u.id}">🗑️</button>` : "—"}</td>
      </tr>
    `).join("");

    tbody.querySelectorAll("[data-delete-user]").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = Number(btn.dataset.deleteUser);
        if (!confirm("هل تريد حذف هذا المستخدم؟")) return;
        const res = await authFetch(`${API_BASE}/users/${id}`, { method: "DELETE" });
        const data = await res.json();
        if (!res.ok || !data.success) {
          alert(data.message || "تعذر الحذف");
          return;
        }
        await loadUsers();
      });
    });
  }
}

async function initSettingsPage() {
  if (user.role !== "admin") {
    document.querySelectorAll(".admin-only-block").forEach((el) => el.style.display = "none");
  }

  const settingsRes = await authFetch(`${API_BASE}/settings`);
  const settingsData = await settingsRes.json();
  const s = settingsData.data || {};

  document.getElementById("companyName").value = s.companyName || "";
  document.getElementById("companyPhone").value = s.companyPhone || "";
  document.getElementById("companyEmail").value = s.companyEmail || "";
  document.getElementById("defaultCity").value = s.defaultCity || "";

  document.getElementById("settingsForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = {
      companyName: document.getElementById("companyName").value,
      companyPhone: document.getElementById("companyPhone").value,
      companyEmail: document.getElementById("companyEmail").value,
      defaultCity: document.getElementById("defaultCity").value
    };
    const res = await authFetch(`${API_BASE}/settings`, { method: "PUT", body: JSON.stringify(payload) });
    const data = await res.json();
    alert(data.message || "تم الحفظ");
  });

  document.getElementById("changePasswordForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const currentPassword = document.getElementById("currentPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {
      alert("كلمة المرور الجديدة غير متطابقة");
      return;
    }

    const res = await authFetch(`${API_BASE}/users/change-password`, {
      method: "PUT",
      body: JSON.stringify({ currentPassword, newPassword })
    });
    const data = await res.json();
    alert(data.message || "تم التنفيذ");
    if (data.success) document.getElementById("changePasswordForm").reset();
  });

  const backupBtn = document.getElementById("manualBackupBtn");
  if (backupBtn) {
    backupBtn.addEventListener("click", async () => {
      const res = await authFetch(`${API_BASE}/backups/manual`, { method: "POST" });
      const data = await res.json();
      alert(data.message || "تم إنشاء النسخة");
    });
  }
}

loadPage("dashboard");
