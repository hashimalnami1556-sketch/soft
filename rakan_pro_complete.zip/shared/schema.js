const ClientSchema = {
  id: "number",
  name: "string",
  phone: "string",
  city: "string",
  status: "string",
  balance: "number",
  category: "string",
  notes: "string",
  createdAt: "string",
  avatar: "string|null"
};

const UserSchema = {
  id: "number",
  username: "string",
  password: "string",
  role: "string",
  fullName: "string"
};

module.exports = { ClientSchema, UserSchema };
